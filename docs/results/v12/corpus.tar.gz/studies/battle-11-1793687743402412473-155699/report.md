# Phalanx battle study

Red wins · OPEN FIELD · seed 11

Duration 38.3s. Survivors: 3 / 0.
Recorded from tick 0: 383 steps and 434 decision records.

## Controller comparison

Utility/PyTorch agreement: 59.4% across 434 valid comparisons; 0 unavailable predictions.
Learned-controller fallbacks: 0. Bonsai does not control this battle.

| Action | Decisions in battle |
| --- | ---: |
| ADVANCE | 125 |
| ATTACK | 271 |
| HIGH GROUND | 0 |
| FLANK | 10 |
| REGROUP | 0 |
| RETREAT | 3 |
| HOLD | 0 |
| SEEK COVER | 0 |
| SUPPORT ALLY | 25 |

## Deep telemetry

Build `0.5.0:d4c99ed1e64b9e21`. 723 ordered events, 77 post-step frames and 121 opposed Theus receipts. Trace size: 961309 bytes. Frames include resolved positions, mean motion, health, effort, wounds, practice and technique state. Theus receipts retain dice, defence, critical and actual damage.

Frames are research truth, separate from decision-time perceived observations. Coordinates remain local to this arena; world context is unknown. A stream sequence detects gaps and ordering errors.

## Evidence

[Full battle state](battle.json) · [Machine-readable report](report.json) · [Decision trace](decisions.jsonl)

Decision records contain perceived contacts, features, eligibility masks, baseline scores, controller proposals and the actual executed action. Damage and healing have simulation receipts. If campaign rewards settle, learning.json and learning.md record persisted before/after changes.

## Interpretation

This is one battle. Repeated decisions are correlated, and agreement does not establish better tactics. The live PyTorch policy is frozen; separate research models may be trained from eligible studies. Actual practice and event memories persist. Match results grant no temperament or growth multiplier. Timing measures simulation plus observation capture, excludes rendering and trace disk writes, and does not isolate inference. Interrupted/reset recordings retain complete=false in status.json.
