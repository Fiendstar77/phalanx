# Phalanx battle study

Red wins · OPEN FIELD · seed 8

Duration 49.8s. Survivors: 2 / 0.
Recorded from tick 0: 498 steps and 518 decision records.

## Controller comparison

Utility/PyTorch agreement: 69.7% across 518 valid comparisons; 0 unavailable predictions.
Learned-controller fallbacks: 0. Bonsai does not control this battle.

| Action | Decisions in battle |
| --- | ---: |
| ADVANCE | 178 |
| ATTACK | 315 |
| HIGH GROUND | 0 |
| FLANK | 3 |
| REGROUP | 0 |
| RETREAT | 0 |
| HOLD | 0 |
| SEEK COVER | 0 |
| SUPPORT ALLY | 22 |

## Deep telemetry

Build `0.5.0:d4c99ed1e64b9e21`. 883 ordered events, 100 post-step frames and 150 opposed Theus receipts. Trace size: 1162454 bytes. Frames include resolved positions, mean motion, health, effort, wounds, practice and technique state. Theus receipts retain dice, defence, critical and actual damage.

Frames are research truth, separate from decision-time perceived observations. Coordinates remain local to this arena; world context is unknown. A stream sequence detects gaps and ordering errors.

## Evidence

[Full battle state](battle.json) · [Machine-readable report](report.json) · [Decision trace](decisions.jsonl)

Decision records contain perceived contacts, features, eligibility masks, baseline scores, controller proposals and the actual executed action. Damage and healing have simulation receipts. If campaign rewards settle, learning.json and learning.md record persisted before/after changes.

## Interpretation

This is one battle. Repeated decisions are correlated, and agreement does not establish better tactics. The live PyTorch policy is frozen; separate research models may be trained from eligible studies. Actual practice and event memories persist. Match results grant no temperament or growth multiplier. Timing measures simulation plus observation capture, excludes rendering and trace disk writes, and does not isolate inference. Interrupted/reset recordings retain complete=false in status.json.
