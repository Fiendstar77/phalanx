# How the phalanxes changed

Persisted practice and witnessed event memories. Completion credit is equal for all results; temperament and model weights receive no automatic result reinforcement.

## Team 1

### KING

- Isolation memory: none 0% -> attachment 55%. Reacts when that situation returns.
- Ally loss memory: none 0% -> attachment 35%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

### QUEEN

- Encirclement memory: none 0% -> fear 22%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

### GENERAL

- Isolation memory: none 0% -> attachment 55%. Reacts when that situation returns.
- Encirclement memory: none 0% -> fear 55%. Reacts when that situation returns.
- Ally loss memory: none 0% -> attachment 25%. Reacts when that situation returns.
- Failed charge memory: none 0% -> hesitation 20%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

## Team 2

### KING

- Class practice 0 -> 25 [###---------] next rank at 100.

### QUEEN

- Isolation memory: none 0% -> recklessness 55%. Reacts when that situation returns.
- Encirclement memory: none 0% -> recklessness 55%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

### GENERAL

- Isolation memory: none 0% -> recklessness 43%. Reacts when that situation returns.
- Encirclement memory: none 0% -> recklessness 8%. Reacts when that situation returns.
- Ally loss memory: none 0% -> recklessness 35%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

