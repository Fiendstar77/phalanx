# Phalanx battle study

Blue wins · THE RIDGE · seed 4

Duration 51.3s. Survivors: 0 / 3.
Recorded from tick 0: 513 steps and 544 decision records.

## Controller comparison

Utility/PyTorch agreement: 68.8% across 544 valid comparisons; 0 unavailable predictions.
Learned-controller fallbacks: 0. Bonsai does not control this battle.

| Action | Decisions in battle |
| --- | ---: |
| ADVANCE | 162 |
| ATTACK | 291 |
| HIGH GROUND | 0 |
| FLANK | 4 |
| REGROUP | 0 |
| RETREAT | 9 |
| HOLD | 0 |
| SEEK COVER | 0 |
| SUPPORT ALLY | 78 |

## Deep telemetry

Build `0.5.0:d4c99ed1e64b9e21`. 923 ordered events, 103 post-step frames and 141 opposed Theus receipts. Trace size: 1191778 bytes. Frames include resolved positions, mean motion, health, effort, wounds, practice and technique state. Theus receipts retain dice, defence, critical and actual damage.

Frames are research truth, separate from decision-time perceived observations. Coordinates remain local to this arena; world context is unknown. A stream sequence detects gaps and ordering errors.

## Evidence

[Full battle state](battle.json) · [Machine-readable report](report.json) · [Decision trace](decisions.jsonl)

Decision records contain perceived contacts, features, eligibility masks, baseline scores, controller proposals and the actual executed action. Damage and healing have simulation receipts. If campaign rewards settle, learning.json and learning.md record persisted before/after changes.

## Interpretation

This is one battle. Repeated decisions are correlated, and agreement does not establish better tactics. The live PyTorch policy is frozen; separate research models may be trained from eligible studies. Actual practice and event memories persist. Match results grant no temperament or growth multiplier. Timing measures simulation plus observation capture, excludes rendering and trace disk writes, and does not isolate inference. Interrupted/reset recordings retain complete=false in status.json.
