# Phalanx battle study

Blue wins · THE RUINS · seed 3

Duration 62.8s. Survivors: 0 / 2.
Recorded from tick 0: 628 steps and 605 decision records.

## Controller comparison

Utility/PyTorch agreement: 84.5% across 605 valid comparisons; 0 unavailable predictions.
Learned-controller fallbacks: 0. Bonsai does not control this battle.

| Action | Decisions in battle |
| --- | ---: |
| ADVANCE | 247 |
| ATTACK | 306 |
| HIGH GROUND | 0 |
| FLANK | 1 |
| REGROUP | 0 |
| RETREAT | 1 |
| HOLD | 2 |
| SEEK COVER | 0 |
| SUPPORT ALLY | 48 |

## Deep telemetry

Build `0.5.0:d4c99ed1e64b9e21`. 1038 ordered events, 126 post-step frames and 157 opposed Theus receipts. Trace size: 1206338 bytes. Frames include resolved positions, mean motion, health, effort, wounds, practice and technique state. Theus receipts retain dice, defence, critical and actual damage.

Frames are research truth, separate from decision-time perceived observations. Coordinates remain local to this arena; world context is unknown. A stream sequence detects gaps and ordering errors.

## Evidence

[Full battle state](battle.json) · [Machine-readable report](report.json) · [Decision trace](decisions.jsonl)

Decision records contain perceived contacts, features, eligibility masks, baseline scores, controller proposals and the actual executed action. Damage and healing have simulation receipts. If campaign rewards settle, learning.json and learning.md record persisted before/after changes.

## Interpretation

This is one battle. Repeated decisions are correlated, and agreement does not establish better tactics. The live PyTorch policy is frozen; separate research models may be trained from eligible studies. Actual practice and event memories persist. Match results grant no temperament or growth multiplier. Timing measures simulation plus observation capture, excludes rendering and trace disk writes, and does not isolate inference. Interrupted/reset recordings retain complete=false in status.json.
