# Phalanx battle study

Blue wins · THE RIDGE · seed 8

Duration 58.8s. Survivors: 0 / 3.
Recorded from tick 0: 588 steps and 668 decision records.

## Controller comparison

Utility/PyTorch agreement: 53.0% across 668 valid comparisons; 0 unavailable predictions.
Learned-controller fallbacks: 0. Bonsai does not control this battle.

| Action | Decisions in battle |
| --- | ---: |
| ADVANCE | 175 |
| ATTACK | 379 |
| HIGH GROUND | 0 |
| FLANK | 11 |
| REGROUP | 0 |
| RETREAT | 19 |
| HOLD | 1 |
| SEEK COVER | 0 |
| SUPPORT ALLY | 83 |

## Deep telemetry

Build `0.5.0:d4c99ed1e64b9e21`. 1173 ordered events, 118 post-step frames and 190 opposed Theus receipts. Trace size: 1484801 bytes. Frames include resolved positions, mean motion, health, effort, wounds, practice and technique state. Theus receipts retain dice, defence, critical and actual damage.

Frames are research truth, separate from decision-time perceived observations. Coordinates remain local to this arena; world context is unknown. A stream sequence detects gaps and ordering errors.

## Evidence

[Full battle state](battle.json) · [Machine-readable report](report.json) · [Decision trace](decisions.jsonl)

Decision records contain perceived contacts, features, eligibility masks, baseline scores, controller proposals and the actual executed action. Damage and healing have simulation receipts. If campaign rewards settle, learning.json and learning.md record persisted before/after changes.

## Interpretation

This is one battle. Repeated decisions are correlated, and agreement does not establish better tactics. The live PyTorch policy is frozen; separate research models may be trained from eligible studies. Actual practice and event memories persist. Match results grant no temperament or growth multiplier. Timing measures simulation plus observation capture, excludes rendering and trace disk writes, and does not isolate inference. Interrupted/reset recordings retain complete=false in status.json.
