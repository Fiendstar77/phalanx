# How the phalanxes changed

Persisted practice and witnessed event memories. Completion credit is equal for all results; temperament and model weights receive no automatic result reinforcement.

## Team 1

### KING

- Isolation memory: none 0% -> fear 55%. Reacts when that situation returns.
- Encirclement memory: none 0% -> fear 48%. Reacts when that situation returns.
- Ally loss memory: none 0% -> hesitation 35%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

### QUEEN

- Isolation memory: none 0% -> fear 55%. Reacts when that situation returns.
- Encirclement memory: none 0% -> fear 23%. Reacts when that situation returns.
- Ally loss memory: none 0% -> hesitation 25%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

### GENERAL

- Class practice 0 -> 25 [###---------] next rank at 100.

## Team 2

### KING

- Ally loss memory: none 0% -> attachment 25%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

### QUEEN

- Isolation memory: none 0% -> attachment 9%. Reacts when that situation returns.
- Encirclement memory: none 0% -> fear 13%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

### GENERAL

- Encirclement memory: none 0% -> fear 8%. Reacts when that situation returns.
- Ally loss memory: none 0% -> attachment 25%. Reacts when that situation returns.
- Class practice 0 -> 25 [###---------] next rank at 100.

